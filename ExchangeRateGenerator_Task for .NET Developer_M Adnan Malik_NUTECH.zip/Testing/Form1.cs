﻿//<<<Developer Information>>>

//Muhammad Adnan Malik
//BSCS Batch 2020 (8th Semester)
//Roll No: F20605005
//National University of Technology (NUTECH)
//Submitted to What Sales for .Net Developer Position


//<<<Start of the program>>>

// Import necessary libraries
using System; // For DateTime class
using System.Collections.Generic;  // For List class
using System.Net.Http; // For HttpClient class
using System.Net.Http.Headers; // For MediaTypeWithQualityHeaderValue class
using System.Threading.Tasks; // For Task class and async methods 
using System.Windows.Forms;   // For Form class
using Newtonsoft.Json.Linq; // For JObject class and JSON parsing methods

namespace Testing // Namespace for the project 
{
    // Main form class
    public partial class Form1 : Form // Class name Form1
    {
        // API base URL and API key
        private const string API_BASE_URL = "https://api.apilayer.com/exchangerates_data"; // API base URL for exchange rates
        private const string API_KEY = "y5GDEeJ5UqfubfUrqYnvVo1WP1rUMS6n"; // API key for authentication
        // HttpClient object for API requests
        private readonly HttpClient httpClient; // HttpClient object for API requests

        // Constructor
        public Form1() // Constructor for the class Form1
        {
            InitializeComponent(); // Initialize components of the form (design elements)
            // Initialize HttpClient with API key
            httpClient = new HttpClient(); // Initialize HttpClient object for API requests 
            httpClient.DefaultRequestHeaders.Add("apikey", API_KEY); // Add API key to request headers 
        }

        // Button click event handler to generate queries
        private async void generateQueriesButton_Click(object sender, EventArgs e) // Method to generate queries for exchange rates 
        {
            // Get selected currency and date range
            string currencyCode = currencyComboBox.SelectedItem?.ToString(); // Get selected currency code from ComboBox 
            DateTime fromDate = fromDateTimePicker.Value.Date; // Get selected start date from DateTimePicker
            DateTime toDate = toDateTimePicker.Value.Date; // Get selected end date from DateTimePicker

            // Validate selected currency
            if (string.IsNullOrWhiteSpace(currencyCode)) // Check if currency code is empty or null
            {
                MessageBox.Show("Please select a currency."); // Show error message if currency is not selected
                return; // Return from the method
            } 

            // Clear previous queries and generate new ones
            queriesTextBox.Clear(); // Clear previous queries from TextBox 
            await GenerateQueries(currencyCode, fromDate, toDate); // Generate new queries for exchange rates
        }

        // Method to generate SQL queries for exchange rates
        private async Task GenerateQueries(string currencyCode, DateTime fromDate, DateTime toDate) // Method to generate SQL queries for exchange rates
        {
            // Start from the end date and go back to the start date
            DateTime currentDate = toDate; // Set current date to end date
            while (currentDate >= fromDate) // Loop through each date in the range
            {
                // Construct API URL for the specific date
                string apiUrl = $"{API_BASE_URL}/timeseries?start_date={currentDate:yyyy-MM-dd}&end_date={currentDate:yyyy-MM-dd}&base=EUR"; // Construct API URL for exchange rates

                try // Try block to handle exceptions 
                {
                    // Make API request
                    HttpResponseMessage response = await httpClient.GetAsync(apiUrl); // Make API request to fetch exchange rates

                    // Check if request was successful
                    if (response.IsSuccessStatusCode) // Check if API request was successful
                    {
                        // Read response content
                        string responseContent = await response.Content.ReadAsStringAsync(); // Read response content as string
                        dynamic exchangeRateData = JObject.Parse(responseContent); // Parse JSON response into dynamic object

                        // Check if API call was successful
                        if (exchangeRateData.success == true) // Check if API call was successful 
                        {
                            // Get exchange rate for the specified currency
                            var rates = exchangeRateData.rates[currentDate.ToString("yyyy-MM-dd")]; // Get exchange rates for the specified date   
                            double exchangeRate = rates[currencyCode]; // Get exchange rate for the specified currency code
                            // Construct SQL query
                            string query = $"IF NOT EXISTS (SELECT 1 FROM ExchangeRatesUSD WHERE Currency = '{currencyCode}' AND '{currentDate:yyyy-MM-dd}' BETWEEN FromDate AND ToDate) BEGIN INSERT INTO ExchangeRatesUSD (Currency, Rate, FromDate, ToDate) VALUES ('{currencyCode}', {exchangeRate}, '{currentDate:yyyy-MM-dd} 00:00:00', '{currentDate:yyyy-MM-dd} 23:59:59') END;"; // Construct SQL query for exchange rates
                            // Append query to TextBox
                            queriesTextBox.AppendText(query + Environment.NewLine); // Append query to TextBox with new line
                        }
                        else // If API call was not successful 
                        {
                            // Show error message if API call was not successful
                            MessageBox.Show($"Failed to fetch exchange rates for {currencyCode} on {currentDate:yyyy-MM-dd}. Error: {exchangeRateData.error.message}"); // Show error message if API call was not successful
                        }
                    }
                    else // If API request was not successful
                    {
                        // Show error message if request was not successful
                        string errorMessage = await response.Content.ReadAsStringAsync(); // Read error message from response content
                        MessageBox.Show($"Failed to fetch exchange rates for {currencyCode} on {currentDate:yyyy-MM-dd}. Error: {errorMessage}"); // Show error message if request was not successful
                    }
                }
                catch (Exception ex) // Catch block to handle exceptions
                {
                    // Show generic error message if an exception occurs
                    MessageBox.Show($"An error occurred: {ex.Message}"); // Show generic error message if an exception occurs
                }

                // Move to the previous day
                currentDate = currentDate.AddDays(-1);  // Move to the previous day in the date range
            }
        }

        // Method to fetch all currency codes
        private async Task<List<string>> GetAllCurrencyCodes() // Method to fetch all currency codes
        {
            List<string> currencyCodes = new List<string>(); // List to store currency codes

            try // Try block to handle exceptions
            {
                // Construct API URL for currency symbols
                string apiUrl = $"{API_BASE_URL}/symbols"; // Construct API URL for currency symbols
                // Make API request
                HttpResponseMessage response = await httpClient.GetAsync(apiUrl); // Make API request to fetch currency symbols
                // Check if request was successful
                if (response.IsSuccessStatusCode) // Check if API request was successful
                {
                    // Read response content
                    string responseContent = await response.Content.ReadAsStringAsync(); // Read response content as string
                    dynamic symbolsData = JObject.Parse(responseContent); // Parse JSON response into dynamic object
                    // Extract currency symbols
                    foreach (var symbol in symbolsData.symbols) // Loop through each currency symbol
                    {
                        currencyCodes.Add(symbol.Name); // Add currency code to the list
                    }
                }
                else // If API request was not successful
                {
                    // Show error message if request was not successful
                    MessageBox.Show("Failed to fetch currency symbols."); // Show error message if request was not successful
                }
            }
            catch (Exception ex) // Catch block to handle exceptions
            {
                // Show generic error message if an exception occurs
                MessageBox.Show($"An error occurred while fetching currency symbols: {ex.Message}"); // Show generic error message if an exception occurs
            }

            return currencyCodes; // Return list of currency codes
        }

        // Form load event handler
        private async void Form1_Load(object sender, EventArgs e) // Method to handle form load event
        {
            // Fetch all currency codes and populate ComboBox
            List<string> currencyCodes = await GetAllCurrencyCodes(); // Fetch all currency codes
            currencyComboBox.Items.AddRange(currencyCodes.ToArray()); // Populate ComboBox with currency codes

            // Select first item by default if available
            if (currencyComboBox.Items.Count > 0) // Check if ComboBox has items
                currencyComboBox.SelectedIndex = 0; // Select first item in ComboBox
        }
    }
}

// <<< End of the program. Enjoy your experience! >>>